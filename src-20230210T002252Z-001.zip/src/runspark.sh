./bin/spark-submit --master spark://master:7077 --jars elasticsearch-hadoop-7.17.5.jar --driver-class-path elasticsearch-hadoop-7.17.5.jar src/main.py 
